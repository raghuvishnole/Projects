import { Router } from "express";
import { getHistory, saveData } from "../controllers/data.controller.js";

const router = Router();

router.get("/history", getHistory);
router.post("/savedata", saveData);

export default router;
