// models/Sensor.js
import mongoose from "mongoose";

const SensorSchema = new mongoose.Schema({
  temperature: Number,
  humidity: Number,
  status: String,
  timestamp: { type: Date, default: Date.now },
});

export default mongoose.model("Sensor", SensorSchema);
