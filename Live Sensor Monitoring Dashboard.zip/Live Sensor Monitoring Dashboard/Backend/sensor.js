// server.js
import express from "express";
import axios from "axios";

const app = express();
app.use(express.json());

const SENSOR_API_URL = "http://localhost:8080/api/savedata"; // Adjust based on your actual API

// Simulated sensor data generator
const generateSensorData = () => ({
  temperature: Math.random() * (60 - 10) + 10, 
  humidity: Math.random() * (100 - 10) + 10, 
  status: "active",
});

// Function to send sensor data to the API

const sendSensorData = async () => {
  const sensorData = generateSensorData();
  try {
    const response = await axios.post(SENSOR_API_URL, sensorData);
    // console.log("Data sent successfully:", response.data);
  } catch (error) {
    console.error("Error sending data:", error);
  }
};

// Schedule data sending every 5 seconds
setInterval(sendSensorData, 5000);

const PORT = 4000;
app.listen(PORT, () => {
  console.log(`Sensor server running on port ${PORT}`);
});
