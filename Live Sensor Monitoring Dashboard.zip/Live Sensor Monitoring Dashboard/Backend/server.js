import express from "express";
import http from "http";
import mongoose from "mongoose";
import cors from "cors";
import { Server } from "socket.io";
import dataRoute from "./routes/data.route.js";
import SensorModel from "./models/Sensor.model.js";

const app = express();
app.use(cors({ origin: "http://localhost:5173" }));
app.use(express.json());
app.use("/api", dataRoute);

const server = http.createServer(app);

//  Socket.IO with CORS
const io = new Server(server, {
  cors: {
    origin: "http://localhost:5173",
    methods: ["GET", "POST"],
  },
});

io.on("connection", (socket) => {
  console.log(` New client connected: ${socket.id}`);

  // Emit mock sensor data every second
  let interval = setInterval(async () => {
    const latest = await SensorModel.findOne().sort({ timestamp: -1 });
    socket.emit("sensorData", latest);
  }, 5000);

  socket.on("disconnect", () => {
    console.log(`❌ Client disconnected: ${socket.id}`);
    clearInterval(interval);
  });
});

mongoose
  .connect("mongodb://localhost:27017/live_sensor")
  .then(() => console.log(" MongoDB connected"))
  .catch((err) => console.error("❌ MongoDB error:", err));

server.listen(8080, () =>
  console.log(" Backend running on http://localhost:8080")
);
