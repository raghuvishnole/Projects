import Sensor from "../models/Sensor.model.js";

export const getHistory = async (req, res) => {
  const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
  try {
    const sensors = await Sensor.find({ timestamp: { $gte: oneHourAgo } }).sort(
      { timestamp: -1 }
    );
    res.json(Array.isArray(sensors) ? sensors : []);
  } catch (error) {
    // console.log(error);
    res
      .status(500)
      .json({ message: "Error fetching sensor history", error: error.message });
  }
};

export const saveData = async (req, res) => {
  const { temperature, humidity, status } = req.body;
  const newSensor = new Sensor({ temperature, humidity, status });
  await newSensor.save();
  res.status(201).json(newSensor);
};
