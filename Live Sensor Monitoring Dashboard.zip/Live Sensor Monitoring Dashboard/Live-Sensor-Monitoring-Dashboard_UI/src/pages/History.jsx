import React, { useEffect, useState } from "react";
import axios from "axios";
import { Line } from "react-chartjs-2";
import "chart.js/auto";
import { Link } from "react-router-dom";

const History = () => {
  const [dataPoints, setDataPoints] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:8080/api/history")
      .then((res) => {
        setDataPoints(res.data);
      //  console.log(res.data);
      })
      .catch(console.error);
  }, []);

  const chartTempratureData = {
    labels: dataPoints.map((d) => new Date(d.timestamp).toLocaleTimeString()),
    datasets: [
      {
        label: "Temperature (°C)",
        data: dataPoints.map((d) => d.temperature),
        fill: false,
        borderColor: "#60a5fa",
        backgroundColor: "rgba(96, 165, 250, 0.2)",
        borderWidth: 3,
        tension: 0.4,
      },
    ],
  };

  const chartHumidityData = {
    labels: dataPoints.map((d) => new Date(d.timestamp).toLocaleTimeString()),
    datasets: [
      {
        label: "Humidity (%)",
        data: dataPoints.map((d) => d.humidity),
        fill: false,
        borderColor: "rgb(255, 138, 3)",
        backgroundColor: "rgba(255, 234, 4, 0.2)",
        borderWidth: 3,
        tension: 0.4,
      },
    ],
  };

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-b from-white to-blue-100">
      <h2 className="text-2xl font-bold mb-6 text-center">
        🌡️ Temperature History (Last Hour)
      </h2>
      <div className="w-full max-w-4xl p-6 m-4 bg-white rounded-xl shadow-lg border border-blue-300">
        <Line data={chartTempratureData} />
      </div>
      <h2 className="text-2xl font-bold mb-6 text-center">
        💧 Humidity History (Last Hour)
      </h2>
      <div className="w-full max-w-4xl p-6 m-4 bg-white rounded-xl shadow-lg border border-blue-300">
        <Line data={chartHumidityData} />
      </div>
      
      <Link
        to="/"
        className="absolute top-4 right-4 bg-blue-500 text-white px-6 py-2 rounded-md text-lg font-semibold hover:bg-blue-600 shadow-md"
      >
        Home
      </Link>
    </div>
  );
};

export default History;
