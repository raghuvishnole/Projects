import React, { useEffect, useState } from "react";
import socket from "../socket.js";
import AlertBanner from "../components/AlertBanner";
import { Link } from "react-router-dom";

const Home = () => {
  const [sensor, setSensor] = useState(null);
  const [isOnline, setIsOnline] = useState(socket.connected); 

  useEffect(() => {
    const handleConnect = () => setIsOnline(true);
    const handleDisconnect = () => setIsOnline(false);

    socket.on("connect", handleConnect);
    socket.on("disconnect", handleDisconnect);
    socket.on("sensorData", (data) => {
      setSensor(data);
    });

    return () => {
      socket.off("connect", handleConnect);
      socket.off("disconnect", handleDisconnect);
      socket.off("sensorData");
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-200 to-blue-50 flex flex-col items-center justify-center p-6">
      <h2 className="text-4xl font-extrabold text-gray-800 mb-6">
        Live Sensor Monitoring Dashboard
      </h2>

      {sensor ? (
        <div className="w-full max-w-lg bg-white shadow-xl rounded-xl p-8 space-y-4">
          <div className="flex justify-between text-xl text-gray-700 font-semibold">
            <span>🌡️ Temperature:</span>
            <span>{sensor.temperature}°C</span>
          </div>
          <div className="flex justify-between text-xl text-gray-700 font-semibold">
            <span>💧 Humidity:</span>
            <span>{sensor.humidity}%</span>
          </div>
          <div className="flex justify-between text-xl text-gray-700 font-semibold">
            <span>{isOnline ? "🟢" : "🔴"} Status:</span>
            <span>{isOnline ? "Online" : "Offline"}</span>
          </div>
          <AlertBanner
            temperature={sensor.temperature}
            humidity={sensor.humidity}
          />
        </div>
      ) : (
        <p className="text-lg text-gray-600">Waiting for sensor data...</p>
      )}

      <Link
        className="bg-blue-500 rounded-md text-white px-10 py-2 mt-4 text-xl font-bold hover:bg-blue-600 shadow-md"
        to="/history"
      >
        History
      </Link>
    </div>
  );
};

export default Home;
