import React from "react";

const AlertBanner = ({ temperature, humidity }) => {
  const isTempHigh = temperature > 50;
  const isHumidityHigh = humidity > 90;

  if (!isTempHigh && !isHumidityHigh) return null;

  return (
    <div className="bg-red-500 text-white text-lg font-semibold p-4 rounded-lg shadow-md flex flex-col items-center space-y-2 animate-pulse">
      {isTempHigh && <p>🔥 Warning: High Temperature!</p>}
      {isHumidityHigh && <p>💧 Warning: High Humidity!</p>}
    </div>
  );
};

export default AlertBanner;
